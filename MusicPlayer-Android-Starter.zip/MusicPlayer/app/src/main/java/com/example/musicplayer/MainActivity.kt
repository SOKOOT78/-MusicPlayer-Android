package com.example.musicplayer

import android.Manifest
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

private val Bg = Color(0xFF0B0912)
private val Panel = Color(0xFF191326)
private val Purple = Color(0xFF9B5CFF)
private val Muted = Color(0xFFAAA1B8)

data class Song(val title: String, val artist: String, val uri: Uri)

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent { MusicPlayerScreen() }
    }

    @Composable
    private fun MusicPlayerScreen() {
        var songs by remember { mutableStateOf(emptyList<Song>()) }
        var current by remember { mutableStateOf<Song?>(null) }
        var isPlaying by remember { mutableStateOf(false) }
        var onlineUrl by remember { mutableStateOf("") }
        var status by remember { mutableStateOf("برای شروع، موسیقی‌های گوشی را بارگذاری کنید.") }

        fun loadSongs() {
            val list = mutableListOf<Song>()
            val collection = if (Build.VERSION.SDK_INT >= 29)
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val projection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST
            )
            val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
            val cursor: Cursor? = contentResolver.query(collection, projection, selection, null,
                "${MediaStore.Audio.Media.TITLE} ASC")
            cursor?.use {
                val idCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                while (it.moveToNext()) {
                    val id = it.getLong(idCol)
                    val uri = Uri.withAppendedPath(collection, id.toString())
                    val title = it.getString(titleCol) ?: "بدون نام"
                    val artist = it.getString(artistCol)?.takeIf { a -> a != "<unknown>" } ?: "هنرمند ناشناس"
                    list.add(Song(title, artist, uri))
                }
            }
            songs = list
            status = if (list.isEmpty()) "آهنگی در حافظه پیدا نشد." else "${list.size} آهنگ پیدا شد."
        }

        fun play(uri: Uri, song: Song? = null) {
            player?.setMediaItem(MediaItem.fromUri(uri))
            player?.prepare()
            player?.play()
            current = song ?: Song("پخش آنلاین", uri.lastPathSegment ?: "Stream", uri)
            isPlaying = true
            status = "در حال پخش"
        }

        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
            else Manifest.permission.READ_EXTERNAL_STORAGE
        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) loadSongs() else status = "برای نمایش آهنگ‌ها باید اجازه دسترسی داده شود."
        }

        MaterialTheme(colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Purple, onBackground = Color.White,
            onSurface = Color.White
        )) {
            Column(
                Modifier.fillMaxSize().background(Bg).statusBarsPadding().padding(horizontal = 20.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 20.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).clip(RoundedCornerShape(15.dp))
                        .background(Brush.linearGradient(listOf(Purple, Color(0xFF5A2AA8)))),
                        contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.GraphicEq, null, tint = Color.White)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("MUSIC PLAYER", color = Color.White, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("موسیقی، همیشه همراه تو", color = Muted, fontSize = 12.sp)
                    }
                    Icon(Icons.Default.Headphones, null, tint = Purple, modifier = Modifier.size(27.dp))
                }

                Text("کتابخانه موسیقی", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text(status, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp, bottom = 14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = {
                        if (ContextCompat.checkSelfPermission(this@MainActivity, permission) == PackageManager.PERMISSION_GRANTED) loadSongs()
                        else launcher.launch(permission)
                    }, colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                        Icon(Icons.Default.FolderOpen, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(7.dp)); Text("بارگذاری آهنگ‌ها")
                    }
                    OutlinedButton(onClick = { onlineUrl = onlineUrl.trim() }, border = androidx.compose.foundation.BorderStroke(1.dp, Purple)) {
                        Icon(Icons.Default.Language, null, tint = Purple); Spacer(Modifier.width(5.dp)); Text("آنلاین")
                    }
                }

                OutlinedTextField(
                    value = onlineUrl, onValueChange = { onlineUrl = it },
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                    placeholder = { Text("آدرس مستقیم MP3 یا استریم") },
                    singleLine = true, shape = RoundedCornerShape(14.dp),
                    trailingIcon = {
                        IconButton(onClick = {
                            val url = onlineUrl.trim()
                            if (url.startsWith("https://") || url.startsWith("http://")) play(Uri.parse(url))
                            else status = "لطفاً یک آدرس معتبر http یا https وارد کنید."
                        }) { Icon(Icons.Default.PlayArrow, "پخش آنلاین", tint = Purple) }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Purple, unfocusedBorderColor = Panel,
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White
                    )
                )

                Text("آهنگ‌های من", fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 22.dp, bottom = 10.dp))
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(songs) { song ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                                .background(Panel).clickable { play(song.uri, song) }.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF302044)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.MusicNote, null, tint = Purple)
                            }
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                                Text(song.artist, color = Muted, fontSize = 12.sp)
                            }
                            Icon(Icons.Default.PlayCircle, null, tint = Purple)
                        }
                    }
                }

                current?.let { song ->
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                        .background(Brush.horizontalGradient(listOf(Color(0xFF241537), Panel)))
                        .padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF39234F)),
                                contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Album, null, tint = Purple, modifier = Modifier.size(28.dp))
                            }
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text(song.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(song.artist, color = Muted, fontSize = 12.sp)
                            }
                            Icon(Icons.Default.GraphicEq, null, tint = Purple)
                        }
                        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { player?.seekToPreviousMediaItem() }) { Icon(Icons.Default.SkipPrevious, null, tint = Color.White) }
                            IconButton(onClick = {
                                if (player?.isPlaying == true) { player?.pause(); isPlaying = false }
                                else { player?.play(); isPlaying = true }
                            }, modifier = Modifier.size(54.dp).clip(CircleShape).background(Purple)) {
                                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White)
                            }
                            IconButton(onClick = { player?.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, null, tint = Color.White) }
                        }
                    }
                } ?: Spacer(Modifier.height(8.dp))
                Spacer(Modifier.height(12.dp))
            }
        }
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
